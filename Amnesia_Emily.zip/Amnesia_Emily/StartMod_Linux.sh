#!/bin/bash
 
FCNAME="Amnesia_Emily"
 
# 64-bit operating systems
if [ "$(uname -m)" = "x86_64" ]; then
  ../Amnesia.bin64 "$FCNAME/config/main_init.cfg"
 
# 32-bit operating systems
else
  ../Amnesia.bin "$FCNAME/config/main_init.cfg"
fi